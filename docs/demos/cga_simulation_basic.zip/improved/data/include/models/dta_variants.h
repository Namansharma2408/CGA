#pragma once
#include "models/inference.h"
#include <vector>
#include <cmath>
#include <random>

class DTA_UCB : public DTA {
    struct Arm {
        double threshold;
        int trials{0};
        double total_reward{0.0};
        double mean() const { return trials > 0 ? total_reward / trials : 0.0; }
    };
    std::vector<Arm> x_arms;
    int active_arm{-1};

public:
    DTA_UCB(const MatrixStats& ms) : DTA(ms) {
        for (double t : {0.01, 0.05, 0.1, 0.2, 0.3}) x_arms.push_back({t, 0, 0.0});
    }

    std::string select_kernel(const FeatureVector& feat) override {
        int best_idx = 0;
        double max_ucb = -1e9;
        int total_trials = 0;
        for (const auto& arm : x_arms) total_trials += arm.trials;

        for (int i = 0; i < (int)x_arms.size(); ++i) {
            double ucb = x_arms[i].mean();
            if (x_arms[i].trials > 0) {
                ucb += 0.2 * std::sqrt(std::log(total_trials + 1.0) / x_arms[i].trials);
            } else {
                ucb = 1e9;
            }
            if (ucb > max_ucb) { max_ucb = ucb; best_idx = i; }
        }
        active_arm = best_idx;
        double current_tx = x_arms[active_arm].threshold;

        if (feat[10] >= current_tx) return "SpMV";
        return DTA::select_kernel(feat);
    }

    void update(const std::string& kernel, double time_ms, const FeatureVector& feat) override {
        DTA::update(kernel, time_ms, feat);
        if (active_arm != -1) {
            double reward = 100.0 / (time_ms + 1e-6);
            x_arms[active_arm].trials++;
            x_arms[active_arm].total_reward += reward;
        }
    }
};

class DTA_Gradient : public DTA {
    double m_tx{0}, v_tx{0};
    double beta1{0.9}, beta2{0.999};
    int t{0};

public:
    DTA_Gradient(const MatrixStats& ms) : DTA(ms) {}

    void update(const std::string& kernel, double time_ms, const FeatureVector& feat) override {
        DTA::update(kernel, time_ms, feat);
        if (kernel == "SpMV") {
            t++;
            double grad = (time_ms > 10.0) ? -0.1 : 0.1;
            m_tx = beta1 * m_tx + (1 - beta1) * grad;
            v_tx = beta2 * v_tx + (1 - beta2) * grad * grad;
            double m_hat = m_tx / (1 - std::pow(beta1, t));
            double v_hat = v_tx / (1 - std::pow(beta2, t));
        }
    }
};
